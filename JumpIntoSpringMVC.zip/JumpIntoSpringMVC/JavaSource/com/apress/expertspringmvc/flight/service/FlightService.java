package com.apress.expertspringmvc.flight.service;

import java.util.List;

import com.apress.expertspringmvc.flight.domain.Flight;
import com.apress.expertspringmvc.flight.domain.FlightSearchCriteria;
import com.apress.expertspringmvc.flight.domain.SpecialDeal;

public interface FlightService {

    List<SpecialDeal> getSpecialDeals();
    
    List<Flight> findFlights(FlightSearchCriteria search);
    
}
