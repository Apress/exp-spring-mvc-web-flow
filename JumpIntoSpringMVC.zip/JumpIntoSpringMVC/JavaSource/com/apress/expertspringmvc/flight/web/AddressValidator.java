package com.apress.expertspringmvc.flight.web;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class AddressValidator implements Validator {

    public boolean supports(Class clazz) {
        // TODO Auto-generated method stub
        return false;
    }

    public void validate(Object obj, Errors errors) {
        // TODO Auto-generated method stub

    }

}
