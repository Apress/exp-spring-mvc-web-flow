package com.apress.expertspringmvc.flight.domain;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

public class FlightTest extends TestCase {
    
    private Flight flight;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    private Airport fooCity;
    private Airport barCity;
    
    public void setUp() throws Exception {
        super.setUp();
        fooCity = new Airport("foo", "F");
        barCity = new Airport("bar", "B");
        
        List<FlightLeg> legs = createSingleLeg();
        flight = new Flight(legs, new BigDecimal(40));
    }
    
    public void testGetTotalCost() {
        assertEquals(40, flight.getTotalCost());
    }
    
    public void testGetDepartFrom() {
        assertEquals(fooCity, flight.getDepartFrom());
    }
    
    public void testGetArriveAt() {
        assertEquals(barCity, flight.getArrivalAt());
    }
    
    public void testGetNumberOfLegs() {
        assertEquals(1, flight.getNumberOfLegs());
    }
    
    public void testIsNonStopOneLeg() {
        List<FlightLeg> legs = createSingleLeg();
        flight = new Flight(legs, new BigDecimal(40));
        assertTrue(flight.isNonStop());
    }

    public void testIsNonStopTwoLegs() {
        List<FlightLeg> legs = createSingleLeg();
        flight = new Flight(legs, new BigDecimal(40));
        legs.add(new FlightLeg(fooCity, new Date(), barCity, new Date()));
        assertFalse(flight.isNonStop());
    }

    public void testGetTotalTravelTimeOneLeg() throws Exception {
        Date start = sdf.parse("2005-01-01 06:00");
        Date end = sdf.parse("2005-01-01 12:00");
        
        List<FlightLeg> legs = new ArrayList<FlightLeg>();
        legs.add(new FlightLeg(fooCity, start, barCity, end));
        flight = new Flight(legs, new BigDecimal(40));
        
        assertEquals((6*60*60*1000), flight.getTotalTravelTime());
    }
    
    public void testGetTotalTravelTimeTwoLegs() throws Exception {
        Date start = sdf.parse("2005-01-01 06:00");
        Date end = sdf.parse("2005-01-01 12:00");
        
        List<FlightLeg> legs = new ArrayList<FlightLeg>();
        legs.add(new FlightLeg(fooCity, start, barCity, end));
        flight = new Flight(legs, new BigDecimal(40));
        
        Date secondStart = new Date(end.getTime());
        Date secondEnd = sdf.parse("2005-01-01 14:30");
        legs.add(new FlightLeg(new Airport("secondFoo", "F2"), secondStart,
                new Airport("secondBar", "B2"), secondEnd));
        
        assertEquals((8*60*60*1000)+(30*60*1000), flight.getTotalTravelTime());
    }
    
    public void testWrongEndTime() throws Exception {
        Date start = sdf.parse("2005-02-01 06:30");
        Date end = sdf.parse("2005-02-01 04:00");
        List<FlightLeg> legs = new ArrayList<FlightLeg>();
        legs.add(new FlightLeg(fooCity, start, barCity, end));
        flight = new Flight(legs, new BigDecimal(40));
        
        try {
            flight.getTotalTravelTime();
            fail("Should have thrown exception");
        } catch(IllegalArgumentException e) {
            assertEquals("Start date must be before end date", e.getMessage());
        }
    }

    private List<FlightLeg> createSingleLeg() {
        List<FlightLeg> legs = new ArrayList<FlightLeg>();
        legs.add(new FlightLeg(fooCity, new Date(), barCity, new Date()));
        return legs;
    }

}
