package com.apress.expertspringmvc.flight.domain;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.TestCase;

public class SpecialDealTest extends TestCase {
    private SpecialDeal deal;
    private Airport airport = new Airport("foo", "FOO");
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public void testIsValidNow() throws Exception {
        Date begin = sdf.parse("2004-01-01");
        Date end = sdf.parse("2009-01-01");
        deal = new SpecialDeal(airport, airport, new BigDecimal(100), begin, end);
        assertTrue(deal.isValidNow());
    }
    
    public void testIsValidOn() throws Exception {
        Date begin = sdf.parse("2004-01-01");
        Date end = sdf.parse("2009-01-01");
        deal = new SpecialDeal(airport, airport, new BigDecimal(100), begin, end);
        assertTrue(deal.isValidOn(begin));
        assertTrue(deal.isValidOn(end));
        
        Date on = sdf.parse("1990-01-01");
        assertFalse(deal.isValidOn(on));
        
        on = sdf.parse("2020-01-01");
        assertFalse(deal.isValidOn(on));
    }

}
