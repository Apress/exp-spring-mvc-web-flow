package com.apress.expertspringmvc.flight.tests;

import java.util.List;

import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.AbstractTransactionalSpringContextTests;
import org.springframework.web.servlet.ModelAndView;

import com.apress.expertspringmvc.flight.domain.SpecialDeal;
import com.apress.expertspringmvc.flight.web.HomeController;

public class HomeControllerIntegrationTest extends
        AbstractTransactionalSpringContextTests {
    
    private HomeController homeController;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;
    
    
    
    public HomeControllerIntegrationTest() {
        setDependencyCheck(false);
    }

    public void setHomeController(HomeController homeController) {
        this.homeController = homeController;
    }
    
    @Override
    protected void onSetUpBeforeTransaction() throws Exception {
        super.onSetUpBeforeTransaction();
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
    }

    @SuppressWarnings("unchecked")
    public void testRequest() throws Exception {
        request.setMethod("GET");
        ModelAndView mav = homeController.handleRequest(request, response);
        assertNotNull(mav);
        List<SpecialDeal> specials = (List<SpecialDeal>)
                mav.getModel().get("specials");
        assertNotNull(specials);
        assertTrue(specials.size() > 0);
    }

    @Override
    protected String[] getConfigLocations() {
        return new String[]{"classpath:applicationContext.xml",
                "classpath:spring-servlet.xml"};
    }
}
